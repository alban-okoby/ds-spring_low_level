package com.digitalsouag.salaire;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalaireApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalaireApplication.class, args);
	}

}
