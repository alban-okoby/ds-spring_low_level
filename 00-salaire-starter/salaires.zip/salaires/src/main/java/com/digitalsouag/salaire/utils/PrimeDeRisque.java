package com.digitalsouag.salaire.utils;

public interface PrimeDeRisque {
    double PRIME = 200;
}
