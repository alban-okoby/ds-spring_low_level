package com.digitalsouag.salaire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalaireApplicationTests {

	@Test
	void contextLoads() {
	}

}
